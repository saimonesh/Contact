package com.example.sai.contact8;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends Activity {


    ListView lv;
    Context context;


    ArrayList prgmName;
    public static int[] prgmImages = {R.drawable.img2, R.drawable.img2, R.drawable.img2, R.drawable.img2, R.drawable.img2, R.drawable.img2, R.drawable.img2, R.drawable.img2, R.drawable.img2};
    public static String[] prgmNameList = {"sai", "vishwa", "saran", "anand", "noufal", "maddy", "mani", "raghul", "ashwin"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        context = this;

        lv = (ListView) findViewById(R.id.listView);
        lv.setAdapter(new CustomAdapter(this, prgmNameList, prgmImages));


    }
}
